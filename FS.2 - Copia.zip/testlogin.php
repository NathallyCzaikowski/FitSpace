<?php
session_start();    //iniciar sessao

// print_r($_REQUEST);  //nao pode estar vazia
if(isset($_POST['submit']) && !empty($_POST['email']) && !empty($_POST['senha']))
{
  //acessa vulgo conexao
    include_once('config.php');
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    // print_r('Email: ' . $email);
    // print_r('Senha: ' . $senha);

    $sql = "SELECT * FROM usuarios WHERE email = '$email' and senha = '$senha'";
    // verifica se o email existe 

    $result = $conexao->query($sql);

    // print_r($sql);
    // print_r($result);

    if(mysqli_num_rows($result) < 1) 
    {
        unset($_SESSION['email']);   // destroi os dados qn existe
        unset($_SESSION['senha']);
        header('Location: login.html');
    }
    else
    {
        $_SESSION['email'] = $email;
        $_SESSION['senha'] = $senha;
        header('Location: sistema.html');
    }
}
else
{
    //nao acessa
    header('Location: login.html');
}

?>
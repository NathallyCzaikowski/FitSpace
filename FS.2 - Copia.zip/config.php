<?

$dbHost = 'Localhost';
$dbUsername = 'root';
$dbPassoword = '';
$dbName = 'formulariofs';     // Banco

$conexao = new mysqli($dbHost,$dbUsername,$dbPassoword,$dbName);

 // if($conexao->connect_error)
    // {
    //     echo "Erro";
    // }
    // else
    // {
    //     echo "Conexao efetuada com sucesso!!";
    // }
?>